/*
 * BoozeUp Level Scan (Android module)
 * © 2026 Vanguard Logic Development. All rights reserved.
 *
 * CODE INDEX
 *   [A1] Settings ............ HOME, HOST
 *   [A2] Start-up ............ onCreate (screen, web view, camera, label reader)
 *   [A3] Camera permission ... onPermissionRequest, onRequestPermissionsResult
 *   [A4] Links ............... only the Level Scan address opens inside the app
 *   [A5] Label and barcode reader ... LabelBridge.readText, LabelBridge.readBarcode (ML Kit, on the phone)
 *   [A6] Back button and close
 *   [A7] Marker board ........ LabelBridge.rectify -> straighten (OpenCV: finds the board markers, straightens the photo)
 */
package com.vanguardlogic.levelscan;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;
import org.opencv.android.OpenCVLoader;
import org.opencv.calib3d.Calib3d;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.core.MatOfInt;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.ArucoDetector;
import org.opencv.objdetect.DetectorParameters;
import org.opencv.objdetect.Objdetect;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    /* [A1] Settings */
    private static final String HOST = "boozeup.vanguardlogicdev.com";
    private static final String HOME = "https://" + HOST + "/levelscan/?app=1";
    private static final int CAMERA_CODE = 7;

    private WebView web;
    private TextRecognizer reader;
    private BarcodeScanner codes;
    private PermissionRequest pending;
    private volatile boolean onOurPage = false;
    private final ExecutorService work = Executors.newSingleThreadExecutor();
    private ArucoDetector aruco;

    /* [A2] Start-up */
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        reader = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        codes = BarcodeScanning.getClient();
        try {
            if (OpenCVLoader.initDebug()) {
                DetectorParameters p = new DetectorParameters();
                p.set_cornerRefinementMethod(Objdetect.CORNER_REFINE_SUBPIX);
                aruco = new ArucoDetector(Objdetect.getPredefinedDictionary(Objdetect.DICT_4X4_50), p);
            }
        } catch (Throwable e) {
            aruco = null;
        }

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.addJavascriptInterface(new LabelBridge(), "LevelScanNative");
        web.setWebViewClient(new Links());
        web.setWebChromeClient(new Chrome());

        if (state != null) web.restoreState(state);
        else web.loadUrl(HOME);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    private static boolean ours(Uri u) {
        return u != null && "https".equals(u.getScheme()) && HOST.equalsIgnoreCase(u.getHost());
    }

    /* [A3] Camera permission: the page asks for the camera, Android asks the user once */
    private class Chrome extends WebChromeClient {
        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            runOnUiThread(() -> {
                boolean wantsCamera = false;
                for (String r : request.getResources()) {
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) wantsCamera = true;
                }
                if (!wantsCamera || !ours(request.getOrigin())) { request.deny(); return; }
                if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                } else {
                    if (pending != null) pending.deny();
                    pending = request;
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_CODE);
                }
            });
        }

        @Override
        public void onPermissionRequestCanceled(PermissionRequest request) {
            if (pending == request) pending = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code != CAMERA_CODE || pending == null) return;
        boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (ok) pending.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
        else pending.deny();
        pending = null;
    }

    /* [A4] Links: only the Level Scan address opens inside the app; other links open in the browser */
    private class Links extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            if (ours(u)) return false;
            try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
            return true;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            onOurPage = ours(Uri.parse(url));
        }
    }

    /* [A5] Label and barcode reader: the page sends a picture, ML Kit reads it on the phone (no internet needed) */
    private class LabelBridge {
        @JavascriptInterface
        public String version() { return "3"; }

        @JavascriptInterface
        public void rectify(final String id, final String dataUrl) {
            if (!valid(id, dataUrl)) return;
            work.execute(() -> answer(id, straighten(dataUrl)));
        }

        @JavascriptInterface
        public void readText(final String id, final String dataUrl) {
            if (!valid(id, dataUrl)) return;
            Bitmap bmp = picture(dataUrl);
            if (bmp == null) { answer(id, ""); return; }
            reader.process(InputImage.fromBitmap(bmp, 0))
                    .addOnSuccessListener(result -> answer(id, result.getText()))
                    .addOnFailureListener(e -> answer(id, ""));
        }

        @JavascriptInterface
        public void readBarcode(final String id, final String dataUrl) {
            if (!valid(id, dataUrl)) return;
            Bitmap bmp = picture(dataUrl);
            if (bmp == null) { answer(id, ""); return; }
            codes.process(InputImage.fromBitmap(bmp, 0))
                    .addOnSuccessListener(list -> {
                        String value = "";
                        for (Barcode b : list) { if (b.getRawValue() != null) { value = b.getRawValue(); break; } }
                        answer(id, value);
                    })
                    .addOnFailureListener(e -> answer(id, ""));
        }
    }

    private boolean valid(String id, String dataUrl) {
        return onOurPage && id != null && dataUrl != null && id.matches("[A-Za-z0-9_]{1,20}") && dataUrl.length() < 12_000_000;
    }

    private static Bitmap picture(String dataUrl) {
        try {
            int comma = dataUrl.indexOf(',');
            byte[] bytes = Base64.decode(comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        } catch (Exception e) {
            return null;
        }
    }

    private void answer(final String id, final String text) {
        final String js = "window.__lsNative&&window.__lsNative(" + JSONObject.quote(id) + "," + JSONObject.quote(text == null ? "" : text) + ")";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    /* [A7] Marker board: same layout as the printed A4 board (sizes in mm, origin at the bottom-left corner, Y goes up).
       Markers DICT_4X4_50, ids 0-5. The photo is straightened to the board plane at 3 pixels per mm. */
    private static final double MARK = 30.0;
    private static final double[][] POS = {{6, 24}, {6, 124}, {6, 224}, {174, 24}, {174, 124}, {174, 224}};
    private static final double OUT_X0 = 0, OUT_X1 = 210, OUT_Y0 = -60, OUT_Y1 = 450, OUT_S = 3;
    private static final double[][] CLEAN = {{166, 261, 44, 36}};   // logo box, painted white
    private static final double MAX_ERR = 1.5;                       // mean marker corner error allowed (photo pixels)

    private static Point outPx(double x, double y) {
        return new Point((x - OUT_X0) * OUT_S, (OUT_Y1 - y) * OUT_S);
    }

    private static double[][] cornersMm(int i) {   // ArUco corner order: top-left, top-right, bottom-right, bottom-left
        double x = POS[i][0], y = POS[i][1], s = MARK;
        return new double[][]{{x, y + s}, {x + s, y + s}, {x + s, y}, {x, y}};
    }

    private static Point apply(double[] h, double x, double y) {
        double w = h[6] * x + h[7] * y + h[8];
        return new Point((h[0] * x + h[1] * y + h[2]) / w, (h[3] * x + h[4] * y + h[5]) / w);
    }

    private static double[] invert(double[] m) {
        double a = m[0], b = m[1], c = m[2], d = m[3], e = m[4], f = m[5], g = m[6], h = m[7], k = m[8];
        double A = e * k - f * h, B = -(d * k - f * g), C = d * h - e * g;
        double det = a * A + b * B + c * C;
        if (Math.abs(det) < 1e-12) return null;
        return new double[]{A / det, -(b * k - c * h) / det, (b * f - c * e) / det,
                B / det, (a * k - c * g) / det, -(a * f - c * d) / det,
                C / det, -(a * h - b * g) / det, (a * e - b * d) / det};
    }

    private static String failed(int n) {
        return "{\"ok\":false,\"n\":" + n + "}";
    }

    private String straighten(String dataUrl) {
        Mat photo = null, gray = null, ids = null, hom = null, out = null;
        List<Mat> corners = new ArrayList<>();
        try {
            if (aruco == null) return failed(0);
            int comma = dataUrl.indexOf(',');
            byte[] bytes = Base64.decode(comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl, Base64.DEFAULT);
            photo = Imgcodecs.imdecode(new MatOfByte(bytes), Imgcodecs.IMREAD_COLOR);
            if (photo.empty()) return failed(0);
            gray = new Mat();
            Imgproc.cvtColor(photo, gray, Imgproc.COLOR_BGR2GRAY);
            ids = new Mat();
            aruco.detectMarkers(gray, corners, ids);

            List<Point> src = new ArrayList<>(), dst = new ArrayList<>();
            boolean[] seen = new boolean[POS.length];
            int n = 0;
            for (int k = 0; k < corners.size() && k < ids.rows(); k++) {
                int i = (int) ids.get(k, 0)[0];
                if (i < 0 || i >= POS.length || seen[i]) continue;
                seen[i] = true;
                n++;
                double[][] mm = cornersMm(i);
                Mat c = corners.get(k);
                for (int j = 0; j < 4; j++) {
                    double[] p = c.get(0, j);
                    src.add(new Point(p[0], p[1]));
                    dst.add(outPx(mm[j][0], mm[j][1]));
                }
            }
            if (n < 2) return failed(n);

            MatOfPoint2f s = new MatOfPoint2f(), d = new MatOfPoint2f();
            s.fromList(src);
            d.fromList(dst);
            hom = Calib3d.findHomography(s, d, Calib3d.RANSAC, 3.0 * OUT_S);
            if (hom == null || hom.empty()) return failed(n);
            double[] h = new double[9];
            hom.get(0, 0, h);
            double[] hi = invert(h);
            if (hi == null) return failed(n);

            double err = 0;   // marker corners taken back to the photo: how well the board fits
            for (int j = 0; j < src.size(); j++) {
                Point b = apply(hi, dst.get(j).x, dst.get(j).y);
                err += Math.hypot(b.x - src.get(j).x, b.y - src.get(j).y);
            }
            err /= src.size();
            if (err > MAX_ERR) return failed(n);

            int ow = (int) Math.round((OUT_X1 - OUT_X0) * OUT_S), oh = (int) Math.round((OUT_Y1 - OUT_Y0) * OUT_S);
            out = new Mat();
            Imgproc.warpPerspective(photo, out, hom, new Size(ow, oh), Imgproc.INTER_LINEAR, Core.BORDER_CONSTANT, new Scalar(255, 255, 255));
            Scalar white = new Scalar(255, 255, 255);
            for (int i = 0; i < POS.length; i++) {   // markers that were seen are painted white (they are not part of the bottle)
                if (!seen[i]) continue;
                double x = POS[i][0], y = POS[i][1];
                Imgproc.rectangle(out, outPx(x - 0.7, y + MARK + 0.7), outPx(x + MARK + 0.7, y - 0.7), white, -1);
            }
            for (double[] r : CLEAN) Imgproc.rectangle(out, outPx(r[0], r[1] + r[3]), outPx(r[0] + r[2], r[1]), white, -1);

            JSONArray poly = new JSONArray();   // the part of the straight picture covered by the photo
            double pw = photo.cols(), ph = photo.rows();
            for (double[] q : new double[][]{{0, 0}, {pw, 0}, {pw, ph}, {0, ph}}) {
                Point o = apply(h, q[0], q[1]);
                poly.put(Math.round(o.x * 10) / 10.0);
                poly.put(Math.round(o.y * 10) / 10.0);
            }
            MatOfByte jpg = new MatOfByte();
            Imgcodecs.imencode(".jpg", out, jpg, new MatOfInt(Imgcodecs.IMWRITE_JPEG_QUALITY, 92));
            JSONObject o = new JSONObject();
            o.put("ok", true);
            o.put("n", n);
            o.put("err", Math.round(err * 1000) / 1000.0);
            o.put("img", "data:image/jpeg;base64," + Base64.encodeToString(jpg.toArray(), Base64.NO_WRAP));
            o.put("poly", poly);
            return o.toString();
        } catch (Throwable e) {
            return failed(0);
        } finally {
            if (photo != null) photo.release();
            if (gray != null) gray.release();
            if (ids != null) ids.release();
            if (hom != null) hom.release();
            if (out != null) out.release();
            for (Mat c : corners) c.release();
        }
    }

    /* [A6] Back button and close */
    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (reader != null) reader.close();
        if (codes != null) codes.close();
        work.shutdownNow();
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
